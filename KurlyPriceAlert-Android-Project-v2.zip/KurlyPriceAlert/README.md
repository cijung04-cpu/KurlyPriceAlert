# 컬리 가격 알리미 — PC 없이 GitHub에서 APK 빌드하기

이 프로젝트는 Android Studio/PC 없이 GitHub Actions 클라우드 러너에서 APK를 빌드하도록 구성할 수 있습니다.

## 가장 쉬운 방법 (스마트폰 브라우저)

1. GitHub 계정으로 https://github.com 에 로그인합니다.
2. `New repository`를 누르고 저장소 이름을 `KurlyPriceAlert`로 입력합니다. `Public` 또는 `Private` 중 선택하고 `Create repository`를 누릅니다.
3. 저장소 화면에서 `Add file` → `Upload files`를 선택합니다.
4. 이 프로젝트 ZIP 파일 `KurlyPriceAlert-Android-Project.zip`을 업로드하고 `Commit changes`를 누릅니다.
5. `Add file` → `Create new file`을 선택합니다.
6. 파일 이름 칸에 아래 경로를 정확히 입력합니다: `.github/workflows/android-apk.yml`
7. 별도 제공된 `android-apk.yml` 파일의 내용을 전부 복사해 붙여넣고 `Commit changes`를 누릅니다.
8. 저장소의 `Actions` 탭을 엽니다. `Build Kurly Price Alert APK` 작업이 실행됩니다. 실행 중이면 기다립니다.
9. 작업이 초록색 체크로 끝나면 해당 실행 항목을 열고 아래쪽 `Artifacts`에서 `KurlyPriceAlert-debug-apk`를 눌러 다운로드합니다.
10. 다운로드한 ZIP을 휴대폰에서 압축 해제하고 `app-debug.apk`를 눌러 설치합니다. Android가 안내하면 브라우저/파일 관리자의 '이 출처 허용'을 켜고 설치합니다.

## 빌드 설정 파일

GitHub 저장소에 만들어야 할 파일 경로는 `.github/workflows/android-apk.yml`입니다. 이 파일의 전체 내용은 함께 제공된 `android-apk.yml` 파일에 있습니다.

워크플로는 저장소 루트에 업로드된 `KurlyPriceAlert-Android-Project.zip`을 압축 해제하고 JDK 17, Android SDK 35, Gradle 8.9로 Debug APK를 빌드한 뒤 GitHub Actions Artifact로 14일간 보관합니다. Gradle 버전은 Android Gradle Plugin 8.7.3에 맞춰 8.9로 고정했습니다.

## 주의 사항

- GitHub Actions가 실행되려면 저장소에 ZIP 파일과 워크플로 파일이 모두 커밋되어야 합니다. 두 파일이 올라간 뒤 `Actions` 탭에서 수동으로 다시 실행할 수도 있습니다.
- GitHub 무료 계정은 공개 저장소에서 Actions 사용이 가능하며, 비공개 저장소는 계정별 무료 사용량 한도가 적용됩니다.
- APK는 Debug 서명 빌드입니다. 개인 기기 테스트용이며 Play 스토어 배포용 서명 릴리스가 아닙니다.
- 이 빌드 과정은 앱을 컴파일할 뿐, 마켓컬리 사이트의 실제 가격 추출 성공을 보증하지 않습니다. 가격 데이터가 JS로만 표시되거나 접근이 차단되면 앱이 가격을 읽지 못할 수 있습니다.
- 현재 앱의 장바구니 가져오기는 장바구니에서 공유/복사한 텍스트에 상품 URL이 포함되어 있을 때 일괄 등록하는 기능입니다. 마켓컬리 계정 장바구니를 로그인 연동으로 자동 동기화하는 기능은 아닙니다.
- WorkManager 정기 작업은 Android 배터리 정책에 따라 15분보다 늦게 실행될 수 있습니다.
- 마켓컬리 로그인 비밀번호, 세션 쿠키, 개인 인증정보를 GitHub에 올리지 마세요.

## 앱 기능

- 상품 URL 개별 등록
- URL이 포함된 장바구니 텍스트 또는 Android 공유 메뉴를 통한 일괄 등록
- Room 데이터베이스에 상품 및 가격 이력 저장
- WorkManager를 이용한 15/30/60분 주기 확인
- 가격 인상/인하 Android 알림
- 수동 가격 확인 및 상품 삭제

## 기술 구성

- Kotlin, Android Gradle Plugin 8.7.3, Gradle 8.9, JDK 17
- compileSdk 35 / minSdk 26 / targetSdk 35
- Room 2.6.1, WorkManager 2.10.0, Jsoup 1.18.3
