package com.example.kurlypricealert

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.work.*
import com.example.kurlypricealert.data.PriceDatabase
import com.example.kurlypricealert.data.Product
import com.example.kurlypricealert.worker.PriceWorker
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
    private val dao by lazy { PriceDatabase.get(this).dao() }
    private lateinit var list: LinearLayout
    private lateinit var urlInput: EditText
    private lateinit var cartInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        buildScreen()
        scheduleMonitoring(15)
        handleSharedText(intent)
        refresh()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSharedText(intent)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(36, 32, 36, 24); setBackgroundColor(0xFFFFFFFF.toInt()) }
        val title = TextView(this).apply { text = "컬리 가격 알리미"; textSize = 25f; setTextColor(0xFF241B2F.toInt()); setPadding(0, 0, 0, 8) }
        root.addView(title)
        status = TextView(this).apply { text = "가격 감시가 15분 간격으로 실행됩니다."; textSize = 13f; setTextColor(0xFF666666.toInt()) }
        root.addView(status)

        root.addView(section("① 상품 링크 등록"))
        urlInput = EditText(this).apply { hint = "마켓컬리 상품 URL 붙여넣기"; singleLine = true }
        root.addView(urlInput, matchWidth())
        root.addView(Button(this).apply { text = "상품 등록"; setOnClickListener { addUrl(urlInput.text.toString()) } }, matchWidth())

        root.addView(section("② 장바구니 상품 일괄 가져오기"))
        cartInput = EditText(this).apply { hint = "장바구니에서 복사한 내용 또는 상품 URL 여러 개 붙여넣기"; minLines = 3; gravity = android.view.Gravity.TOP }
        root.addView(cartInput, matchWidth())
        root.addView(Button(this).apply { text = "붙여넣은 상품 가져오기"; setOnClickListener { importCartText(cartInput.text.toString()) } }, matchWidth())

        root.addView(section("③ 가격 감시"))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val interval = Spinner(this)
        val choices = listOf("15분 간격" to 15L, "30분 간격" to 30L, "1시간 간격" to 60L)
        interval.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices.map { it.first })
        controls.addView(interval, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        controls.addView(Button(this).apply { text = "주기 설정"; setOnClickListener { val mins = choices[interval.selectedItemPosition].second; scheduleMonitoring(mins); status.text = "가격 감시 주기: ${mins}분" } })
        root.addView(controls)
        root.addView(Button(this).apply { text = "지금 가격 확인"; setOnClickListener { runNow(); status.text = "가격 확인 작업을 요청했습니다." } }, matchWidth())

        root.addView(section("등록된 상품"))
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun section(text: String) = TextView(this).apply { this.text = text; textSize = 17f; setTextColor(0xFF342447.toInt()); setPadding(0, 22, 0, 8) }
    private fun matchWidth() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun addUrl(raw: String) {
        val url = raw.trim()
        if (!url.startsWith("https://") || !(url.contains("kurly.com") || url.contains("marketkurly.com"))) {
            Toast.makeText(this, "marketkurly.com 또는 kurly.com 상품 URL을 입력해 주세요.", Toast.LENGTH_LONG).show(); return
        }
        lifecycleScope.launch {
            if (dao.byUrl(url) == null) dao.insert(Product(url = url, name = "상품 정보 확인 중"))
            urlInput.setText("")
            refresh(); runNow()
        }
    }

    private fun importCartText(text: String) {
        val urls = Regex("https?://[^\\s<>\\\"']+").findAll(text).map { it.value.trimEnd('.', ',', ')', ']') }
            .filter { it.contains("kurly.com") || it.contains("marketkurly.com") }.distinct().toList()
        if (urls.isEmpty()) {
            Toast.makeText(this, "복사한 내용에서 컬리 상품 URL을 찾지 못했습니다. 상품 링크가 포함된 텍스트를 붙여넣어 주세요.", Toast.LENGTH_LONG).show(); return
        }
        lifecycleScope.launch {
            var added = 0
            urls.forEach { if (dao.byUrl(it) == null) { dao.insert(Product(url = it, name = "상품 정보 확인 중")); added++ } }
            cartInput.setText(""); refresh(); runNow()
            Toast.makeText(this@MainActivity, "${added}개 상품을 등록했습니다.", Toast.LENGTH_LONG).show()
        }
    }

    private fun refresh() {
        lifecycleScope.launch {
            val products = dao.all()
            list.removeAllViews()
            if (products.isEmpty()) list.addView(TextView(this@MainActivity).apply { text = "아직 등록된 상품이 없습니다."; setPadding(0, 12, 0, 12); setTextColor(0xFF777777.toInt()) })
            products.forEach { p ->
                val row = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 12, 0, 12) }
                row.addView(TextView(this@MainActivity).apply { text = p.name; textSize = 15f; setTextColor(0xFF222222.toInt()) })
                row.addView(TextView(this@MainActivity).apply { text = (p.currentPrice?.let { "현재 확인 가격: ${it}원" } ?: "가격 확인 대기") + "\n" + p.url; textSize = 12f; setTextColor(0xFF777777.toInt()) })
                row.addView(Button(this@MainActivity).apply { text = "삭제"; setOnClickListener { lifecycleScope.launch { dao.delete(p); refresh() } } })
                list.addView(row)
                val line = android.view.View(this@MainActivity).apply { setBackgroundColor(0xFFEAEAEA.toInt()) }
                list.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1))
            }
        }
    }

    private fun scheduleMonitoring(minutes: Long) {
        val request = PeriodicWorkRequestBuilder<PriceWorker>(minutes, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork("kurly-price-monitor", ExistingPeriodicWorkPolicy.UPDATE, request)
    }

    private fun runNow() {
        val request = OneTimeWorkRequestBuilder<PriceWorker>().setConstraints(
            Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(this).enqueue(request)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun handleSharedText(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val shared = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
            if (::cartInput.isInitialized) { cartInput.setText(shared); importCartText(shared) }
        }
    }
}
