package com.example.kurlypricealert.data

import android.content.Context
import androidx.room.*

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val url: String,
    val name: String,
    val currentPrice: Long? = null,
    val lastChecked: Long? = null,
    val enabled: Boolean = true
)

@Entity(tableName = "price_history")
data class PriceHistory(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val productId: Long,
    val price: Long,
    val checkedAt: Long
)

@Dao
interface ProductDao {
    @Query("SELECT * FROM products ORDER BY name COLLATE NOCASE") suspend fun all(): List<Product>
    @Query("SELECT * FROM products WHERE enabled = 1") suspend fun enabled(): List<Product>
    @Query("SELECT * FROM products WHERE url = :url LIMIT 1") suspend fun byUrl(url: String): Product?
    @Insert suspend fun insert(product: Product): Long
    @Update suspend fun update(product: Product)
    @Delete suspend fun delete(product: Product)
    @Insert suspend fun addHistory(history: PriceHistory)
    @Query("SELECT * FROM price_history WHERE productId = :id ORDER BY checkedAt DESC LIMIT 30") suspend fun history(id: Long): List<PriceHistory>
}

@Database(entities = [Product::class, PriceHistory::class], version = 1, exportSchema = false)
abstract class PriceDatabase : RoomDatabase() {
    abstract fun dao(): ProductDao
    companion object {
    @Volatile private var INSTANCE: PriceDatabase? = null
    fun get(context: Context): PriceDatabase = INSTANCE ?: synchronized(this) {
        INSTANCE ?: Room.databaseBuilder(context.applicationContext, PriceDatabase::class.java, "kurly-price.db").build().also { INSTANCE = it }
    }
    }
}
