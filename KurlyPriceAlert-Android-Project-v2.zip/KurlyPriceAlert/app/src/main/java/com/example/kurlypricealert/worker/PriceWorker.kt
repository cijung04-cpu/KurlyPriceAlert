package com.example.kurlypricealert.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.kurlypricealert.R
import com.example.kurlypricealert.data.PriceDatabase
import com.example.kurlypricealert.data.PriceHistory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.jsoup.Jsoup
import org.json.JSONArray
import org.json.JSONObject

class PriceWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val dao = PriceDatabase.get(applicationContext).dao()
            dao.enabled().forEach { product ->
                try {
                    val doc = Jsoup.connect(product.url)
                        .userAgent("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
                        .timeout(20_000).followRedirects(true).get()
                    val title = doc.selectFirst("meta[property=og:title]")?.attr("content")
                        ?.takeIf { it.isNotBlank() } ?: doc.title().ifBlank { product.name }
                    val price = extractPrice(doc.html())
                    val now = System.currentTimeMillis()
                    if (price != null && price > 0) {
                        val previous = product.currentPrice
                        dao.update(product.copy(name = title, currentPrice = price, lastChecked = now))
                        dao.addHistory(PriceHistory(productId = product.id, price = price, checkedAt = now))
                        if (previous != null && previous != price) notifyChange(title, previous, price)
                    } else {
                        dao.update(product.copy(name = title, lastChecked = now))
                    }
                } catch (_: Exception) {
                    // One unavailable page must not stop monitoring the remaining products.
                }
            }
            Result.success()
        } catch (_: Exception) { Result.retry() }
    }

    private fun extractPrice(html: String): Long? {
        val doc = Jsoup.parse(html)
        val candidates = listOf(
            doc.selectFirst("meta[property=product:price:amount]")?.attr("content"),
            doc.selectFirst("meta[property=og:price:amount]")?.attr("content"),
            doc.selectFirst("meta[itemprop=price]")?.attr("content"),
            doc.selectFirst("[itemprop=price]")?.attr("content"),
            doc.selectFirst("[itemprop=price]")?.text()
        )
        for (candidate in candidates) parseWon(candidate)?.let { return it }
        val scripts = doc.select("script[type=application/ld+json]")
        for (script in scripts) {
            val parsed = runCatching { JSONObject(script.data()) }.getOrNull()
            if (parsed != null) findJsonPrice(parsed)?.let { return it }
            val array = runCatching { JSONArray(script.data()) }.getOrNull()
            if (array != null) for (i in 0 until array.length()) findJsonPrice(array.optJSONObject(i) ?: continue)?.let { return it }
        }
        return null
    }

    private fun findJsonPrice(obj: JSONObject): Long? {
        val offers = obj.opt("offers")
        if (offers is JSONObject) parseWon(offers.opt("price")?.toString())?.let { return it }
        if (offers is JSONArray) for (i in 0 until offers.length()) parseWon(offers.optJSONObject(i)?.opt("price")?.toString())?.let { return it }
        val graph = obj.opt("@graph")
        if (graph is JSONArray) for (i in 0 until graph.length()) findJsonPrice(graph.optJSONObject(i) ?: continue)?.let { return it }
        return null
    }

    private fun parseWon(value: String?): Long? {
        if (value.isNullOrBlank()) return null
        val number = value.replace(",", "").replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: return null
        return number.toLong().takeIf { it in 100..100_000_000 }
    }

    private fun notifyChange(name: String, old: Long, new: Long) {
        val manager = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel = "price_changes"
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel(channel, "가격 변동 알림", NotificationManager.IMPORTANCE_DEFAULT))
        val down = new < old
        val diff = kotlin.math.abs(new - old)
        val message = "${old}원 → ${new}원 (${if (down) "${diff}원 인하" else "${diff}원 인상"})"
        val notification = NotificationCompat.Builder(applicationContext, channel)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("컬리 가격 변동: $name")
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT).setAutoCancel(true).build()
        manager.notify((name + System.currentTimeMillis()).hashCode(), notification)
    }
}
